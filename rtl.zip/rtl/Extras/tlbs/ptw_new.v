module ptw_2level #(
    parameter VA_WIDTH          = 32,
    parameter PC_BITS           = 20,
    parameter PAGE_OFFSET_WIDTH = 12,                          // 4 KiB
    parameter VPN_WIDTH         = VA_WIDTH - PAGE_OFFSET_WIDTH, // 20
    parameter PPN_WIDTH         = PC_BITS - PAGE_OFFSET_WIDTH   // 8
)(
    input                       clk,
    input                       rst,

    // ---------- From ITLB ----------
    input                       Itlb_pa_request,
    input  [VPN_WIDTH-1:0]      Itlb_va,

    // ---------- From DTLB ----------
    input                       Dtlb_pa_request,
    input  [VPN_WIDTH-1:0]      Dtlb_va,

    // ---------- Back to ITLB ----------
    output reg                  Itlb_ptw_valid,   // 1-cycle pulse
    output reg [PPN_WIDTH-1:0]  Itlb_ptw_pa,
    output reg                  Itlb_ptw_fault,   // 1-cycle pulse

    // ---------- Back to DTLB ----------
    output reg                  Dtlb_ptw_valid,   // 1-cycle pulse
    output reg [PPN_WIDTH-1:0]  Dtlb_ptw_pa,
    output reg                  Dtlb_ptw_fault,   // 1-cycle pulse

    // ---------- Word-level memory interface (to dcache) ----------
    output reg                  Ptw_mem_req,
    output reg  [PC_BITS-1:0]   Ptw_mem_addr,
    input       [31:0]          Ptw_mem_rdata,
    input                       Ptw_mem_valid,

    // ---------- dcache accepts PTW request ----------
    input                       accepted
);

    // ============================================================
    // root page table PPN
    // ============================================================
    localparam [PPN_WIDTH-1:0] ROOT_PPN = 8'h30; 

    // ============================================================
    // VPN split
    // ============================================================
    reg  [VPN_WIDTH-1:0] vpn_q;
    wire [9:0] vpn1 = vpn_q[VPN_WIDTH-1 -: 10];
    wire [9:0] vpn0 = vpn_q[9:0];

    reg [PPN_WIDTH-1:0] l1_ppn_q;

    // PTE decode 
    wire                 pte_v   = Ptw_mem_rdata[0];
    wire [PPN_WIDTH-1:0] pte_ppn =
        Ptw_mem_rdata[PPN_WIDTH + PAGE_OFFSET_WIDTH - 1 : PAGE_OFFSET_WIDTH];

    // ============================================================
    // port being served
    // ============================================================
    reg serving_itlb;

    // ============================================================
    // Fault tracking 
    // ============================================================
    reg l1_fault_pending;

    // ============================================================
    // States
    // ============================================================
    localparam S_IDLE    = 3'd0;
    localparam S_L1_REQ  = 3'd1;
    localparam S_L1_WAIT = 3'd2;
    localparam S_L2_REQ  = 3'd3;
    localparam S_L2_WAIT = 3'd4;
    localparam S_RESP    = 3'd5;

    reg [2:0] state, next_state;

    // ============================================================
    // Sequential logic
    // ============================================================
    always @(posedge clk) begin
        if (rst) begin
            state            <= S_IDLE;
            vpn_q            <= {VPN_WIDTH{1'b0}};
            l1_ppn_q         <= {PPN_WIDTH{1'b0}};
            serving_itlb     <= 1'b1;
            l1_fault_pending <= 1'b0;

            Itlb_ptw_valid   <= 1'b0;
            Itlb_ptw_pa      <= {PPN_WIDTH{1'b0}};
            Itlb_ptw_fault   <= 1'b0;

            Dtlb_ptw_valid   <= 1'b0;
            Dtlb_ptw_pa      <= {PPN_WIDTH{1'b0}};
            Dtlb_ptw_fault   <= 1'b0;

            Ptw_mem_req      <= 1'b0;
            Ptw_mem_addr     <= {PC_BITS{1'b0}};
        end else begin
            state <= next_state;

            // one-cycle pulses 
            Itlb_ptw_valid <= 1'b0;
            Dtlb_ptw_valid <= 1'b0;
            Itlb_ptw_fault <= 1'b0;
            Dtlb_ptw_fault <= 1'b0;

            case (state)

                // ---------------- IDLE ----------------
                S_IDLE: begin
                    Ptw_mem_req      <= 1'b0;
                    l1_fault_pending <= 1'b0;   

                    if (Itlb_pa_request) begin
                        vpn_q        <= Itlb_va;
                        serving_itlb <= 1'b1;
                    end else if (Dtlb_pa_request) begin
                        vpn_q        <= Dtlb_va;
                        serving_itlb <= 1'b0;
                    end
                end

                // ---------------- L1_REQ ----------------
                // req high until accepted.
                S_L1_REQ: begin
                    Ptw_mem_req  <= 1'b1;
                    Ptw_mem_addr <= {ROOT_PPN, vpn1, 2'b00};
                end

                // ---------------- L1_WAIT ----------------
                S_L1_WAIT: begin
                    Ptw_mem_req <= 1'b0;

                    if (Ptw_mem_valid) begin
                        if (!pte_v) begin
                            // L1 fault;
                            l1_fault_pending <= 1'b1;

                            if (serving_itlb) Itlb_ptw_fault <= 1'b1;
                            else              Dtlb_ptw_fault <= 1'b1;
                        end else begin
                            l1_ppn_q <= pte_ppn;
                        end
                    end
                end

                // ---------------- L2_REQ ----------------
                S_L2_REQ: begin
                    if (!l1_fault_pending) begin
                        Ptw_mem_req  <= 1'b1;
                        Ptw_mem_addr <= {l1_ppn_q, vpn0, 2'b00};
                    end else begin
                        // on L1 fault, suppress request 
                        Ptw_mem_req  <= 1'b0;
                        Ptw_mem_addr <= {PC_BITS{1'b0}};
                    end
                end

                // ---------------- L2_WAIT ----------------
                S_L2_WAIT: begin
                    Ptw_mem_req <= 1'b0;

                    if (Ptw_mem_valid) begin
                        if (!pte_v) begin
                            // L2 invalid -> fault
                            if (serving_itlb) Itlb_ptw_fault <= 1'b1;
                            else              Dtlb_ptw_fault <= 1'b1;
                        end else begin
                            // success ptw_valid here
                            if (serving_itlb) begin
                                Itlb_ptw_pa    <= pte_ppn;
                                Itlb_ptw_valid <= 1'b1;
                            end else begin
                                Dtlb_ptw_pa    <= pte_ppn;
                                Dtlb_ptw_valid <= 1'b1;
                            end
                        end
                    end
                end

                // ---------------- RESP ----------------
                S_RESP: begin
                    Ptw_mem_req <= 1'b0;
                end

                default: begin
                    Ptw_mem_req <= 1'b0;
                end
            endcase
        end
    end

    // ============================================================
    // Next-state logic
    // ============================================================
    always @(*) begin
        next_state = state;
        case (state)
            S_IDLE: begin
                if (Itlb_pa_request || Dtlb_pa_request)
                    next_state = S_L1_REQ;
            end

            S_L1_REQ: begin
                if (accepted)
                    next_state = S_L1_WAIT;
            end

            
            // on mem_valid -> advance to L2_REQ.
            S_L1_WAIT: begin
                if (Ptw_mem_valid)
                    next_state = S_L2_REQ;
            end


            S_L2_REQ: begin
                if (l1_fault_pending) //go to idle
                    next_state = S_RESP;   
                else if (accepted)
                    next_state = S_L2_WAIT; 
            end

            S_L2_WAIT: begin
                if (Ptw_mem_valid)
                    next_state = S_RESP;
            end

            S_RESP: begin
                next_state = S_IDLE;
            end

            default: begin
                next_state = S_IDLE;
            end
        endcase
    end

endmodule